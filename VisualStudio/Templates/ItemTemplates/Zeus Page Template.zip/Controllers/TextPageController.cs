using System.Web.Mvc;
using Zeus.Templates.Mvc.Controllers;
using Zeus.Web;
using $rootnamespace$.ContentTypes;
using $rootnamespace$.ViewModels;

namespace $rootnamespace$.Controllers
{
	[Controls(typeof($classname$), AreaName = WebsiteAreaRegistration.AREA_NAME)]
	public class $classname$Controller : ZeusController<$classname$>
	{
		public override ActionResult Index()
		{
			return View(new $classname$ViewModel(CurrentItem));
		}
	}
}
