using Zeus.Web.Mvc.ViewModels;
using $rootnamespace$.ContentTypes;

namespace $rootnamespace$.ViewModels
{
	public class $classname$ViewModel : ViewModel<$classname$>
	{
		public $classname$ViewModel($classname$ currentItem)
			: base(currentItem)
		{

		}
	}
}
