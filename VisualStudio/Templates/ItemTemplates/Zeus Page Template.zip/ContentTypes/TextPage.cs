using Zeus;
using Zeus.Web;

namespace $rootnamespace$.ContentTypes
{
	[ContentType("$itemname$")]
	public class $safeitemname$ : BasePage
	{
		[ContentProperty("Text", 100)]
		public virtual string Text
		{
			get { return GetDetail("Text", string.Empty); }
			set { SetDetail("Text", value); }
		}
	}
}
